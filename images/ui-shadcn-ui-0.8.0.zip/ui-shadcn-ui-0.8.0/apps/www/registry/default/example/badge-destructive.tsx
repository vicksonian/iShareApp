import { Badge } from "@/registry/default/ui/badge"

export default function BadgeDestructive() {
  return <Badge variant="destructive">Destructive</Badge>
}
