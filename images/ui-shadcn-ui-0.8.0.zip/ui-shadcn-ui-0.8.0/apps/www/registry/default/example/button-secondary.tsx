import { Button } from "@/registry/default/ui/button"

export default function ButtonSecondary() {
  return <Button variant="secondary">Secondary</Button>
}
