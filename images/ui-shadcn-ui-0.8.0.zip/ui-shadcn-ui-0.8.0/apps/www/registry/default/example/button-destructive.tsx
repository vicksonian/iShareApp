import { Button } from "@/registry/default/ui/button"

export default function ButtonDestructive() {
  return <Button variant="destructive">Destructive</Button>
}
